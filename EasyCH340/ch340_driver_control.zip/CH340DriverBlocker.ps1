# 관리자 권한 체크
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Re-launching script with administrator privileges..."
    $scriptPath = $MyInvocation.MyCommand.Definition
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs
    return
}

# 루프 시작
do {
    Write-Host "==== CH340 Driver Update Manager ===="
    Write-Host "1. Block CH340 driver update"
    Write-Host "2. Unblock CH340 driver update"
    Write-Host "3. Install CH340 driver"
    Write-Host "4. Uninstall CH340 driver"
    Write-Host "5. One-click reset & reinstall CH340 driver"
    Write-Host "0. Exit"
    

    $choice = Read-Host "Select an option [0-5]"

    switch ($choice) {
        '1' {
            $targetName = "CH340"
            Write-Host "`nSearching for CH340 device..."
            try {
                $device = Get-PnpDevice | Where-Object { $_.FriendlyName -like "*$targetName*" } | Select-Object -First 1
                if (-not $device) {
                    Write-Host "CH340 device not found. Make sure it's connected."
                    Start-Sleep -Seconds 2
                    break
                }

                $hwidProp = Get-PnpDeviceProperty -InstanceId $device.InstanceId |
                    Where-Object { $_.KeyName -eq "DEVPKEY_Device_HardwareIds" }
                $hardwareId = $hwidProp.Data[0]
                Write-Host "Hardware ID: $hardwareId"

                $regBase = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions"
                $regDeny = "$regBase\DenyDeviceIDs"

                New-Item -Path $regBase -Force | Out-Null
                Set-ItemProperty -Path $regBase -Name "DenyDeviceIDsRetroactive" -Value 1 -Type DWord
                Set-ItemProperty -Path $regBase -Name "DenyDeviceIDs" -Value 1 -Type DWord

                New-Item -Path $regDeny -Force | Out-Null
                Set-ItemProperty -Path $regDeny -Name "1" -Value $hardwareId

                Write-Host "`nCH340 driver update has been blocked."
            } catch {
                Write-Host "An error occurred: $_"
            }
            Start-Sleep -Seconds 2
        }

        '2' {
            $regDeny = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions\DenyDeviceIDs"
            if (Test-Path $regDeny) {
                Remove-ItemProperty -Path $regDeny -Name "1" -ErrorAction SilentlyContinue
                Write-Host "`nCH340 driver update block has been removed."
            } else {
                Write-Host "`nNo block entry found."
            }
            Start-Sleep -Seconds 2
        }

        '3' {
            # 스크립트 실행 경로를 기준으로 CH341SER 폴더 찾기
            $scriptDir = $PSScriptRoot  # $PSScriptRoot를 사용하여 경로를 가져옵니다.
            $setupPath = Join-Path $scriptDir "CH341SER\SETUP.EXE"

            if (Test-Path $setupPath) {
                Write-Host "`nSETUP.EXE found. Installing..."
                $process = Start-Process $setupPath -ArgumentList "/S" -PassThru -Wait
                if ($process.ExitCode -eq 0) {
                    Write-Host "`nDriver installed successfully."
                } else {
                    Write-Host "`nDriver installation failed with exit code: $($process.ExitCode)"
                }
            } else {
                Write-Host "`nSETUP.EXE file not found in CH341SER folder."
            }
            Start-Sleep -Seconds 2
        }

        '4' {
            # 스크립트 실행 경로를 기준으로 CH341SER 폴더 찾기
            $scriptDir = $PSScriptRoot  # $PSScriptRoot를 사용하여 경로를 가져옵니다.
            $setupPath = Join-Path $scriptDir "CH341SER\SETUP.EXE"

            if (Test-Path $setupPath) {
                Write-Host "`nSETUP.EXE found. Uninstalling..."
                $process = Start-Process $setupPath -ArgumentList "/U" -PassThru -Wait
                if ($process.ExitCode -eq 0) {
                    Write-Host "`nDriver uninstalled successfully."
                } else {
                    Write-Host "`nDriver uninstallation failed with exit code: $($process.ExitCode)"
                }
            } else {
                Write-Host "`nSETUP.EXE file not found in CH341SER folder."
            }
            Start-Sleep -Seconds 2
        }

        '5' {
            # Step 1: Unblock
            $regDeny = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions\DenyDeviceIDs"
            if (Test-Path $regDeny) {
                Remove-ItemProperty -Path $regDeny -Name "1" -ErrorAction SilentlyContinue
                Write-Host "`n[1/4] CH340 driver update block removed."
            } else {
                Write-Host "`n[1/4] No previous block entry found."
            }

            # Step 2: Uninstall
            $scriptDir = $PSScriptRoot
            $setupPath = Join-Path $scriptDir "CH341SER\SETUP.EXE"

            if (Test-Path $setupPath) {
                Write-Host "`n[2/4] Uninstalling driver..."
                $process = Start-Process $setupPath -ArgumentList "/U" -PassThru -Wait
                if ($process.ExitCode -eq 0) {
                    Write-Host "[2/4] Driver uninstalled successfully."
                } else {
                    Write-Host "[2/4] Driver uninstallation failed with exit code: $($process.ExitCode)"
                }
            } else {
                Write-Host "[2/4] SETUP.EXE not found for uninstall."
            }

            # Step 3: Install
            if (Test-Path $setupPath) {
                Write-Host "`n[3/4] Installing driver..."
                $process = Start-Process $setupPath -ArgumentList "/S" -PassThru -Wait
                if ($process.ExitCode -eq 0) {
                    Write-Host "[3/4] Driver installed successfully."
                } else {
                    Write-Host "[3/4] Driver installation failed with exit code: $($process.ExitCode)"
                }
            } else {
                Write-Host "[3/4] SETUP.EXE not found for install."
            }

            # Step 4: Block again
            $targetName = "CH340"
            Write-Host "`n[4/4] Searching for CH340 device..."
            try {
                $device = Get-PnpDevice | Where-Object { $_.FriendlyName -like "*$targetName*" } | Select-Object -First 1
                if (-not $device) {
                    Write-Host "[4/4] CH340 device not found. Make sure it's connected."
                    break
                }

                $hwidProp = Get-PnpDeviceProperty -InstanceId $device.InstanceId |
                    Where-Object { $_.KeyName -eq "DEVPKEY_Device_HardwareIds" }
                $hardwareId = $hwidProp.Data[0]
                Write-Host "Hardware ID: $hardwareId"

                $regBase = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions"
                $regDeny = "$regBase\DenyDeviceIDs"

                New-Item -Path $regBase -Force | Out-Null
                Set-ItemProperty -Path $regBase -Name "DenyDeviceIDsRetroactive" -Value 1 -Type DWord
                Set-ItemProperty -Path $regBase -Name "DenyDeviceIDs" -Value 1 -Type DWord

                New-Item -Path $regDeny -Force | Out-Null
                Set-ItemProperty -Path $regDeny -Name "1" -Value $hardwareId

                Write-Host "[4/4] CH340 driver update has been blocked again."
            } catch {
                Write-Host "An error occurred during re-block: $_"
            }

            Start-Sleep -Seconds 2
        }

        '0' {
            Write-Host "`nExiting..."
        }

        default {
            Write-Host "`nInvalid selection. Please choose 1, 2, 3, 4, 5 or 0."
        }
    }

} while ($choice -ne '0')
